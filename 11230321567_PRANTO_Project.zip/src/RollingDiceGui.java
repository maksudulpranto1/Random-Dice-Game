import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class RollingDiceGui extends JFrame {

    public RollingDiceGui() {
        super("Rolling Double Dice");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setPreferredSize(new Dimension(700, 700));
        pack();
        setResizable(false);
        setLocationRelativeTo(null);

        addGuiComponents();
    }

    private void addGuiComponents() {
        JPanel jPanel = new JPanel();
        jPanel.setLayout(null);

        // 1. Banner
        JLabel bannerImg = ImgService.loadImage("resources/banner.png");
        bannerImg.setBounds(45, 25, 600, 100);
        jPanel.add(bannerImg);

        // 2. Player Labels
        JLabel playerOneLabel = new JLabel("Player 1", SwingConstants.CENTER);
        playerOneLabel.setFont(new Font("Arial", Font.BOLD, 16));
        playerOneLabel.setBounds(100, 150, 200, 30);
        jPanel.add(playerOneLabel);

        JLabel playerTwoLabel = new JLabel("Player 2", SwingConstants.CENTER);
        playerTwoLabel.setFont(new Font("Arial", Font.BOLD, 16));
        playerTwoLabel.setBounds(390, 150, 200, 30);
        jPanel.add(playerTwoLabel);

        // 3. Dices
        JLabel diceOneImg = ImgService.loadImage("resources/dice1.png");
        diceOneImg.setBounds(100, 200, 200, 200);
        jPanel.add(diceOneImg);

        JLabel diceTwoImg = ImgService.loadImage("resources/dice1.png");
        diceTwoImg.setBounds(390, 200, 200, 200);
        jPanel.add(diceTwoImg);

        // 4. Roll Button
        JButton rollButton = new JButton("Roll!");
        rollButton.setBounds(250, 550, 200, 50);
        jPanel.add(rollButton);

        // 5. Result Text Box
        JTextField resultTextBox = new JTextField();
        resultTextBox.setBounds(150, 500, 400, 30);
        resultTextBox.setHorizontalAlignment(JTextField.CENTER);
        resultTextBox.setFont(new Font("Arial", Font.PLAIN, 16));
        resultTextBox.setEditable(false);
        jPanel.add(resultTextBox);

        // Random number generator
        Random rand = new Random();

        // Roll Button Action
        rollButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                rollButton.setEnabled(false);

                // Roll for 3 seconds
                long startTime = System.currentTimeMillis();
                Thread rollThread = new Thread(() -> {
                    long endTime = System.currentTimeMillis();
                    try {
                        while ((endTime - startTime) / 1000F < 3) {
                            // Roll dice
                            int diceOne = rand.nextInt(6) + 1; // Generate number between 1 and 6
                            int diceTwo = rand.nextInt(6) + 1; // Generate number between 1 and 6

                            // Update dice images
                            ImgService.updateImage(diceOneImg, "resources/dice" + diceOne + ".png");
                            ImgService.updateImage(diceTwoImg, "resources/dice" + diceTwo + ".png");

                            repaint();
                            revalidate();

                            // Sleep thread
                            Thread.sleep(60);

                            endTime = System.currentTimeMillis();
                        }

                        // Determine the winner
                        int diceOne = rand.nextInt(6) + 1;
                        int diceTwo = rand.nextInt(6) + 1;

                        ImgService.updateImage(diceOneImg, "resources/dice" + diceOne + ".png");
                        ImgService.updateImage(diceTwoImg, "resources/dice" + diceTwo + ".png");

                        if (diceOne > diceTwo) {
                            resultTextBox.setText("Player 1 Wins!");
                        } else if (diceTwo > diceOne) {
                            resultTextBox.setText("Player 2 Wins!");
                        } else {
                            resultTextBox.setText("It's a Tie!");
                        }

                        rollButton.setEnabled(true);
                    } catch (InterruptedException ex) {
                        System.out.println("Threading Error: " + ex);
                    }
                });
                rollThread.start();
            }
        });

        this.getContentPane().add(jPanel);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new RollingDiceGui().setVisible(true);
        });
    }
}
